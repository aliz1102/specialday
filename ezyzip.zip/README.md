### [Hướng dẫn tạo website chúc mừng sinh nhật và upload lên host để gởi cho bạn bè || Part 2](https://)
> Các bạn download source về và làm theo hương dẫn trong video nhé.


![cover picture](./img/hpbd2021p2.jpg)
